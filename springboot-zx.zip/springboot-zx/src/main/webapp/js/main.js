
layui.config({
   // dir: '/res/layui/' //layui.js 所在路径（注意，如果是script单独引入layui.js，无需设定该参数。），一般情况下可以无视
    version: true //一般用于更新模块缓存，默认不开启。设为true即让浏览器不缓存。也可以设为一个固定的值，如：201610
    ,debug: false //用于开启调试模式，默认false，如果设为true，则JS模块的节点会保留在页面
   // ,base: '' //设定扩展的Layui模块的所在目录，一般用于外部模块扩展
});

layui.use('element', function(){
    var element = layui.element;
});

layui.use('upload', function(){
    var upload = layui.upload;
    //执行实例
    var uploadInst = upload.render({
        elem: '#test1' //绑定元素
        ,url: '/zx/testuploadimg' //上传接口
        ,accept: 'file'
        ,done: function(res){
            alert(JSON.stringify(res));
            //上传完毕回调
        }
        ,error: function(){
            alert(12);
            //请求异常回调
        }
    });
});

layui.use('layer', function(){ //独立版的layer无需执行这一句
    var $ = layui.jquery, layer = layui.layer; //独立版的layer无需执行这一句
    //触发事件
    var active = {
        setTop: function(){
            var that = this;
            //多窗口模式，层叠置顶
            layer.open({
                type: 2 //此处以iframe举例
                ,title: '当你选择该窗体时，即会在最顶端'
                ,area: ['550px', '450px']
                ,shade: 0
                ,maxmin: true
                /* ,offset: [ //为了演示，随机坐标
                     Math.random()*($(window).height()-300)
                     ,Math.random()*($(window).width()-390)
                 ]*/
                // ,content: '/girls/save_excel'
                ,content: '/zx/return_template/aa.html'
                ,btn: ['继续弹出', '全部关闭'] //只是为了演示
                ,yes: function(){
                    $(that).click();
                }
                ,btn2: function(){
                    layer.closeAll();
                }
                ,zIndex: layer.zIndex //重点1
                ,success: function(layero){
                    layer.setTop(layero); //重点2
                }
            });
        }
    };

    $('#layerDemo .layui-btn').on('click', function(){
        var othis = $(this), method = othis.data('method');
        active[method] ? active[method].call(this, othis) : '';
    });

});

/* function saveExcel(){
     $.get("/girls/save_excel", function(data){
         alert(data);
     });
 }*/


function showRongyao(){
    $.ajax({
        type: "post",
        url: "/zx/card/toCardShow",
        contentType: "text/html; charset=utf-8",
        dataType: "html",//表示后台返回的数据是json对象
        success: function (data) {
            //由于dataType=json
            //系统会根据后台返回的数据returnValue自动生成一个key=d、value=returnValue的json对象
            //此处的data是json对象
            //我们就可以用data.d获取返回的数据
            $( "#main_body" ).load( data, function( response, status, xhr ) {
                $('#main_body').html(response);
            });
        },
        error: function (error) {
            alert("error=" + error);
        }
    });
}

/**
 * 导入荣耀卡
 */
function import_glorycard(){
    $.ajax({
        type: "post",
        url: "/zx/girls/toImportGloryCard",
        contentType: "text/html; charset=utf-8",
        dataType: "html",//表示后台返回的数据是json对象
        success: function (data) {
            //由于dataType=json
            //系统会根据后台返回的数据returnValue自动生成一个key=d、value=returnValue的json对象
            //此处的data是json对象
            //我们就可以用data.d获取返回的数据
            $( "#main_body" ).load( data, function( response, status, xhr ) {
                $('#main_body').html(response);
            });
        },
        error: function (error) {
            alert("error=" + error);
        }
    });
}


function  showRongyaoB(){
    $.ajax({
        type: "post",
        url: "/zx/girls/getB",
        contentType: "text/html; charset=utf-8",
        dataType: "html",//表示后台返回的数据是json对象
        success: function (data) {
            //由于dataType=json
            //系统会根据后台返回的数据returnValue自动生成一个key=d、value=returnValue的json对象
            //此处的data是json对象
            //我们就可以用data.d获取返回的数据
            $( "#main_body" ).load( data, function( response, status, xhr ) {
                $('#main_body').html(response);
            });
        },
        error: function (error) {
            alert("error=" + error);
        }
    });
}

/**
 * 显示申报记录
 */
function showDeclareRecordList(){
    $.ajax({
        type: "get",
        url: "/zx/card/toDeclareRecord",
        contentType: "text/html; charset=utf-8",
        dataType: "html",//表示后台返回的数据是json对象
        success: function (data) {
            //由于dataType=json
            //系统会根据后台返回的数据returnValue自动生成一个key=d、value=returnValue的json对象
            //此处的data是json对象
            //我们就可以用data.d获取返回的数据
            $( "#main_body" ).load( data, function( response, status, xhr ) {
                $('#main_body').html(response);
            });
        },
        error: function (error) {
            alert("error=" + error);
        }
    });
}


/**
 * 显示周会数据表
 */
function showTableWeek(){
    $.ajax({
        type: "get",
        url: "/zx/card/toShowWeekInfo",
        contentType: "text/html; charset=utf-8",
        dataType: "html",//表示后台返回的数据是json对象
        success: function (data) {
            //由于dataType=json
            //系统会根据后台返回的数据returnValue自动生成一个key=d、value=returnValue的json对象
            //此处的data是json对象
            //我们就可以用data.d获取返回的数据
            $( "#main_body" ).load( data, function( response, status, xhr ) {
                $('#main_body').html(response);
            });
        },
        error: function (error) {
            alert("error=" + error);
        }
    });
}


/**
 * 显示成员信息
 */
function showMemberList(){
    $.ajax({
        type: "get",
        url: "/zx/card/toShowMember",
        contentType: "text/html; charset=utf-8",
        dataType: "html",//表示后台返回的数据是json对象
        success: function (data) {
            //由于dataType=json
            //系统会根据后台返回的数据returnValue自动生成一个key=d、value=returnValue的json对象
            //此处的data是json对象
            //我们就可以用data.d获取返回的数据
            $( "#main_body" ).load( data, function( response, status, xhr ) {
                $('#main_body').html(response);
            });
        },
        error: function (error) {
            alert("error=" + error);
        }
    });
}


