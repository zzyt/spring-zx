

var table;
var tableId = "listReload";
layui.use('table', function(){
    table = layui.table;
    table.render({
        id:tableId
        ,elem: '#showMemberTable'
        ,url:'/zx/card/findMemberList'
        ,cellMinWidth: 200 //全局定义常规单元格的最小宽度，layui 2.2.1 新增
        ,cols: [[
            {field:'name', width:200, title: '姓名', sort: true}
            ,{field:'userId', width:165, title: '编号'}
        ]]
        ,even: true
        ,page: true
        ,loading:true
        ,done: function(res, curr, count){
            //如果是异步请求数据方式，res即为你接口返回的信息。
            //如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
            // alert(JSON.stringify(res));
            //得到当前页码
            // alert(curr);
            //得到数据总量
            // alert(count);
        }
    });
});


function  reloadTable() {
    var userName = $('#userName');
    //执行重载
    table.reload(tableId, {
        page: {
            curr: 1 //重新从第 1 页开始
        }
        ,where: {
            userName: userName.val()
        }
    });
}
