/**
 * 列表取数据
 */
var table;
layui.use('table', function() {
    table = layui.table;
    table.render({
        id: 'listReload'
        , elem: '#main_import'
        , url: '/importRecord/findAll/'
        , cols: [[
            {type: 'checkbox'},
            {field: 'id', width: 80, title: 'ID', sort: true},
            {field: 'importTime', width: 180, title: '导入时间'},
            {field: 'importNum', width: 120, title: '导入数量', align: 'right'},
            {field: 'enableTime', width: 120, title: '启用时间'},
            {field: 'validMouth', width: 120, title: '有效时间(月)', align: 'right'},
            {field: 'enable', width: 120, title: '是否启用'},
            {field: 'createBy', width: 120, title: '创建人'},
            {field: 'createTime', width: 120, title: '创建时间'},
            {field: 'remark', width: 140, title: '备注'},
            {fixed: 'right', width: 90, align: 'center', toolbar: '#barOperate'} //这里的toolbar值是模板元素的选择器
        ]]
        , page: true
        , loading: true
        ,theme: '#1E9FFF'
        , done: function (res, curr, count) {
            //如果是异步请求数据方式，res即为你接口返回的信息。
            //如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
            // alert(JSON.stringify(res));
            //得到当前页码
            // alert(curr);
            //得到数据总量
            // alert(count);
        }
    });

    //监听工具条
    table.on('tool(main_import)', function(obj){
        var data = obj.data;
        if(obj.event === 'detail'){
            queryDetail(data.id);
            /*layer.msg('ID：'+ data.id + ' 的查看操作');*/
        } else if(obj.event === 'del'){
            layer.confirm('真的删除行么', function(index){
                obj.del();
                layer.close(index);
            });
        } else if(obj.event === 'edit'){
            layer.alert('编辑行：<br>'+ JSON.stringify(data))
        }
    });
});


/**
 * 上传excel
 */
layui.use('upload', function(){
    var upload = layui.upload;
    //执行实例
    var uploadInst = upload.render({
        elem: '#import_card' //绑定元素
        ,url: '/importRecord/cardUpload' //上传接口
        ,accept: 'file'
        ,size: 60
        ,exts: 'xls|xlsx' //只允许excel
        ,done: function(res){
           //  alert(JSON.stringify(res));
            alertExcelMsg();
            //上传完毕回调
        }
        ,error: function(){
            alert('导入失败!');
            //请求异常回调
        }
    });
});



function alertExcelMsg(){
    layui.use('layer', function(){ //独立版的layer无需执行这一句
        var $ = layui.jquery,
            layer = layui.layer; //独立版的layer无需执行这一句
        //触发事件
        // var active = {
        //     setTop: function(){
        var that = this;
        //多窗口模式，层叠置顶
        layer.open({
            type: 2 //此处以iframe举例
            ,title: '荣耀卡导入数据预览'
            ,area: ['550px', '450px']
            ,shade: 0
            ,maxmin: true
            /* ,offset: [ //为了演示，随机坐标
                 Math.random()*($(window).height()-300)
                 ,Math.random()*($(window).width()-390)
             ]*/
            // ,content: '/girls/save_excel'
            ,content: 'import_prew.html'
            ,btn: ['确认导入', '全部关闭'] //只是为了演示
            ,yes: function(){
                saveExcel();
                layer.closeAll();
            }
            ,btn2: function(){
                layer.closeAll();
            }
            ,zIndex: layer.zIndex //重点1
            ,success: function(layero){
                layer.setTop(layero); //重点2
            }
        });
    });

    /**
     * 保存excel数据
     */
    function saveExcel(){
        $.post("/importRecord/saveExcel", {},
            function(data,status){
                table.reload("listReload", { //此处是上文提到的 初始化标识id
                });
            });
    }
}



function queryDetail(id){
    sessionStorage.setItem('importId', id);
    layui.use('layer', function(){ //独立版的layer无需执行这一句
        var $ = layui.jquery,
            layer = layui.layer; //独立版的layer无需执行这一句
        //触发事件
        // var active = {
        //     setTop: function(){
        var that = this;
        //多窗口模式，层叠置顶
        layer.open({
            type: 2 //此处以iframe举例
            ,title: '数据明细'
            ,area: ['1050px', '450px']
            ,shade: 0
            ,maxmin: true
            ,content: 'show_detail.html'
            ,btn: ['关闭']
            ,yes: function(){
                layer.closeAll();
            }
            ,zIndex: layer.zIndex //重点1
            ,success: function(layero){
                layer.setTop(layero); //重点2
            }
        });
    });
}


layui.use(['form', 'layedit', 'laydate'], function() {
    var form = layui.form
        , layer = layui.layer
        , layedit = layui.layedit
        , laydate = layui.laydate;

//日期
    laydate.render({
        elem: '#startTime'
    });
    laydate.render({
        elem: '#endTime'
    });
});


function  reloadTable() {
    var startTime = $('#startTime');
    var endTime = $('#endTime');
    //执行重载
    table.reload(tableId, {
        page: {
            curr: 1 //重新从第 1 页开始
        }
        ,where: {
            startTime: startTime.val(),
            endTime: endTime.val()
        }
    });
}