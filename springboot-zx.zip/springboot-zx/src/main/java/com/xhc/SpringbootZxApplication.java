package com.xhc;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.xhc.mapper")
public class SpringbootZxApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootZxApplication.class, args);
	}
}
