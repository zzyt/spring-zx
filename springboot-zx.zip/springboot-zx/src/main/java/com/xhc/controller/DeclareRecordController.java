package com.xhc.controller;

import com.alibaba.fastjson.JSONObject;
import com.xhc.model.DeclareRecord;
import com.xhc.service.imp.DeclareRecordServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
public class DeclareRecordController {

    @Autowired
    private DeclareRecordServiceImpl declareRecordServiceImpl;

    @GetMapping(value = "/declareRecord/findDeclareList")
    public String findDeclareList(HttpServletRequest request){
        Integer page = Integer.parseInt(request.getParameter("page"));
        Integer limit = Integer.parseInt(request.getParameter("limit"));
        String cardCode = request.getParameter("cardCode");
        List<DeclareRecord> declareRecordList = declareRecordServiceImpl.findAllPage(page, limit, cardCode);
        List<DeclareRecord> allList = declareRecordServiceImpl.findAll(null);
        String returnStr = JSONObject.toJSONString(declareRecordList);
        returnStr = "{\"count\":" + allList.size() +",\"code\":"+ 0 + ",\"data\":" + returnStr;
        returnStr += "}";
        return returnStr;
    }
}
