package com.xhc.controller;

import com.alibaba.fastjson.JSONObject;
import com.xhc.service.imp.DeclareRecordServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
public class WeekInfoController {

    @Autowired
    private DeclareRecordServiceImpl declareRecordServiceImpl;

   /* @GetMapping("/card/calCardQtyWeek")
    public String calCardQtyWeek(HttpServletRequest request){
        String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");
        List<Map<String,String>> list = declareRecordServiceImpl.findWeekInfo();

        List<JSONObject> jsonObjectList = new ArrayList<>();
        for (Map<String,String> map : list) {
            JSONObject jsonObject = new JSONObject();
            Set<String> sets = map.keySet();
            for (String st : sets){
                if("cc".equals(st)){
                    jsonObject.put("count",  map.get(st));
                }
                if("name".equals(st)){
                    jsonObject.put("name", map.get(st));
                }
            }
            jsonObjectList.add(jsonObject);
        }
        *//*for(Map<String,String> map : ll){
            JSONObject jsonObject = new JSONObject();
            Set<String> sets = map.keySet();
            for (String st : sets){
                if("cc".equals(st)){
                    jsonObject.put("count",  map.get(st));
                }
                if("name".equals(st)){
                    jsonObject.put("name", map.get(st));
                }
            }
            jsonObjectList.add(jsonObject);
        }*//*

        List<JSONObject> resultList = new ArrayList<>();
        for (int i = 0; i < jsonObjectList.size(); i++) {
            JSONObject firstJsonObject = jsonObjectList.get(i); // 上一个
            JSONObject nextJsonObject = null;
            if(i == jsonObjectList.size()-1){
                break;
                // nextJsonObject = jsonObjectList.get(jsonObjectList.size()-1);
            }else{
                nextJsonObject = jsonObjectList.get(i+1);
            }
            // 下一个
            int firstCount = firstJsonObject.getIntValue("count");
            int nextJCount = nextJsonObject.getIntValue("count");
            if(firstCount == nextJCount){
                nextJsonObject.put("no",i);
                if(resultList.contains(firstJsonObject)){
                    resultList.add(nextJsonObject);
                }else{
                    firstJsonObject.put("no",i+1);
                    resultList.add(firstJsonObject);
                    resultList.add(nextJsonObject);
                }
            }else{
                if (i == 0) {
                    firstJsonObject.put("no", firstJsonObject.getIntValue("no") + 1);
                    resultList.add(firstJsonObject);
                }else {
                   // firstJsonObject.put("no", i + 1);
                    nextJsonObject.put("no", i + 1);
                   // resultList.add(firstJsonObject);
                    resultList.add(nextJsonObject);
                }
            }
        }
       *//* for (int i = 0; i < jsonObjectList.size(); i++) {
            JSONObject firstJsonObject = jsonObjectList.get(i); // 上一个
            JSONObject nextJsonObject = null;
            if(i == jsonObjectList.size()-1){
                break;
                // nextJsonObject = jsonObjectList.get(jsonObjectList.size()-1);
            }else{
                nextJsonObject = jsonObjectList.get(i+1);
            }
            // 下一个
            int firstCount = firstJsonObject.getIntValue("count");
            int nextJCount = nextJsonObject.getIntValue("count");
            if(firstCount == nextJCount){
                nextJsonObject.put("no",i+1);
                if(resultList.contains(firstJsonObject)){
                    resultList.add(nextJsonObject);
                }else{
                    firstJsonObject.put("no",i+1);
                    resultList.add(firstJsonObject);
                    resultList.add(nextJsonObject);
                }
            }else{
                if (i == 0) {
                    firstJsonObject.put("no", firstJsonObject.getIntValue("no") + 1);
                    resultList.add(firstJsonObject);
                }else {
                    firstJsonObject.put("no", i +1);
                    resultList.add(firstJsonObject);
                }
            }
        }*//*

        String returnStr = JSONObject.toJSONString(resultList);
        returnStr = "{\"count\":" + 1 +",\"code\":"+ 0 + ",\"data\":" + returnStr;
        returnStr += "}";
        return returnStr;
    }*/



    @GetMapping("/card/calCardQtyWeek")
    public String calCardQtyWeek(HttpServletRequest request){
        String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");
        List<Map<String,String>> list = declareRecordServiceImpl.findWeekInfo();

        List<JSONObject> jsonObjectList = new ArrayList<>();
        for (int i = 0; i < list.size() ; i++) {
            Map<String,String> map = list.get(i);
            JSONObject jsonObject = new JSONObject();
            Set<String> sets = map.keySet();
            for (String st : sets){
                if("cc".equals(st)){
                    jsonObject.put("count",  map.get(st));
                }
                if("name".equals(st)){
                    jsonObject.put("name", map.get(st));
                }
                jsonObject.put("no", i + 1);
            }
            jsonObjectList.add(jsonObject);
        }
        String returnStr = JSONObject.toJSONString(jsonObjectList);
        returnStr = "{\"count\":" + 1 +",\"code\":"+ 0 + ",\"data\":" + returnStr;
        returnStr += "}";
        return returnStr;
    }
}
