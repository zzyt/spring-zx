package com.xhc.controller;

import com.alibaba.fastjson.JSONObject;
import com.xhc.model.Card;
import com.xhc.model.ImportRecord;
import com.xhc.service.imp.CardImportServiceImpl;
import com.xhc.service.imp.CardServiceImpl;
import com.xhc.utils.FileUtil;
import com.xhc.utils.ResultUtil;
import jxl.Sheet;
import jxl.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;

/**
 * 荣耀卡数据导入功能
 */
@RestController
public class CardImportController {

    @Autowired
    private CardImportServiceImpl cardImportServiceImpl;
    @Autowired
    private CardServiceImpl cardServiceImpl;

    @GetMapping(value = "/importRecord/findAll")
    public String findAllImportRecord(HttpServletRequest request){
        Integer page = Integer.parseInt(request.getParameter("page"));
        Integer limit = Integer.parseInt(request.getParameter("limit"));
        String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");
        List<ImportRecord> recordList = cardImportServiceImpl.findAllPage(page, limit, startTime, endTime);
        List<ImportRecord> allList = cardImportServiceImpl.findAll();
        String returnStr = JSONObject.toJSONString(recordList);
        returnStr = "{\"count\":" + allList.size() +",\"code\":"+ 0 + ",\"data\":" + returnStr;
        returnStr += "}";
        return returnStr;
    }

    //处理文件上传
    @RequestMapping(value="/importRecord/cardUpload", method = RequestMethod.POST)
    public @ResponseBody
    String uploadExcel(@RequestParam("file") MultipartFile file,
                       HttpServletRequest request,
                       HttpSession session) {
        String contentType = file.getContentType();
        String fileName = file.getOriginalFilename();
        String[] filePro = fileName.split("\\.");
        String filePath = request.getSession().getServletContext().getRealPath("upload/");
        fileName = System.currentTimeMillis()+"."+filePro[1];
        try {
            FileUtil.uploadFile(file.getBytes(), filePath, fileName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        session.setAttribute("excelName",fileName);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("status","success");
        //返回json
        return jsonObject.toJSONString();
    }


    // 去读Excel的方法readExcel，该方法的入口参数为一个File对象
    @GetMapping(value = "/importRecord/readCardMsg")
    public String readExcel(HttpSession session, HttpServletRequest request) {
        // 准备返回数据信息
        Map<String,List<String>> map = new HashMap<>();
        List<Card> cardsList = new ArrayList<>();
        String path = request.getSession().getServletContext().getRealPath("upload/");
        String filePath = path+session.getAttribute("excelName");
        File file = new File(filePath);
        try {
            // 创建输入流，读取Excel
            InputStream is = new FileInputStream(file.getAbsolutePath());
            // jxl提供的Workbook类
            Workbook wb = Workbook.getWorkbook(is);
            // Excel的页签数量
            int sheet_size = wb.getNumberOfSheets();
            for (int index = 0; index < sheet_size; index++) {
                // 每个页签创建一个Sheet对象
                Sheet sheet = wb.getSheet(index);
                // sheet.getRows()返回该页的总行数
                for (int i = 0; i < sheet.getRows(); i++) {
                    // sheet.getColumns()返回该页的总列数
                    List<String> codeList = new ArrayList<>();
                    String onwer = "";
                    for (int j = 0; j < sheet.getColumns(); j++) {
                        String cellinfo = sheet.getCell(j, i).getContents();
                        if(j == 0){  //所有者
                            onwer = cellinfo;
                        }else{
                            codeList.add(cellinfo);
                        }
                    }
                    map.put(onwer, codeList);
                }
            }
            // 得到最终的数据map，组装成list
            Set<String> keys = map.keySet();
            for(String key : keys){
                List<String> codeList = map.get(key);
                for(String cardCode : codeList){
                    Card card = new Card();
                    card.setOwner(key);
                    card.setCode(cardCode);
                    cardsList.add(card);
                }
            }
            session.setAttribute("excelData",cardsList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String returnStr = JSONObject.toJSONString(cardsList);
        returnStr = "{\"count\":" + cardsList.size() +",\"code\":"+ 0 + ",\"data\":" + returnStr;
        returnStr += "}";
        return returnStr;
    }

    @PostMapping(value = "/importRecord/saveExcel")
    public String saveExcel(HttpSession session){
        List<Card> cardsList = (List<Card>)session.getAttribute("excelData");
        // 保存card的信息
        cardServiceImpl.saveImportAndCard(cardsList);
        return ResultUtil.success().toString();
    }


    @GetMapping("/importRecord/getdetailByImportId/{id}")
    public String showDetailList(HttpServletRequest request, @PathVariable("id") Integer id){
        Integer page = Integer.parseInt(request.getParameter("page"));
        Integer limit = Integer.parseInt(request.getParameter("limit"));
        List<Card> cardList = cardServiceImpl.findPageByImportId(id, page, limit);
        List<Card> cardAllList = cardServiceImpl.findAllByImportId(id);
        String returnStr = JSONObject.toJSONString(cardList);
        returnStr = "{\"count\":" + cardAllList.size() +",\"code\":"+ 0 + ",\"data\":" + returnStr;
        returnStr += "}";
        return  returnStr;
    }
}
