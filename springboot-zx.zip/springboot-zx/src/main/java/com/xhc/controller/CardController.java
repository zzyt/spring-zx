package com.xhc.controller;

import com.alibaba.fastjson.JSONObject;
import com.xhc.mapper.CardMapper;
import com.xhc.model.Card;
import com.xhc.service.imp.CardServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
public class CardController {

    @Autowired
    private CardServiceImpl cardServiceImpl;

    @GetMapping(value = "/card/findCard")
    public String girlList(HttpServletRequest request){
        Integer page = Integer.parseInt(request.getParameter("page"));
        Integer limit = Integer.parseInt(request.getParameter("limit"));
        String cardCode = request.getParameter("cardCode");
        String owner = request.getParameter("owner");
        List<Card> cardsList = cardServiceImpl.findAll(page,limit,cardCode);
        int count = cardServiceImpl.findCount();
        String returnStr = JSONObject.toJSONString(cardsList);
        returnStr = "{\"count\":" + count +",\"code\":"+ 0 + ",\"data\":" + returnStr;
        returnStr += "}";
        return returnStr;
    }
}
