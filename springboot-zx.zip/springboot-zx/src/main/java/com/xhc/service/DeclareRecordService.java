package com.xhc.service;

import com.xhc.model.DeclareRecord;

import java.util.List;
import java.util.Map;

public interface DeclareRecordService {

    List<DeclareRecord> findAllPage(int pageNum, int pageSize, String declareCardCode);

    List<DeclareRecord> findAll(String declareCardCode);

    List<Map<String,String>> findWeekInfo();
}
