package com.xhc.service;

import com.xhc.model.Card;
import com.xhc.model.ImportRecord;

import java.util.List;

public interface CardService {

    int addCard(Card card);

    List<Card> findAll(int pageNum, int pageSize);

    void saveImportAndCard(List<Card> cardList);

    void insertBatch(List<Card> cardList);

    List<Card> findPageByImportId(Integer importId, int pageNum, int pageSize);

    List<Card> findAllByImportId(Integer importId);

    int findCount();

    List<Card> findAll(String code);

    List<Card> findAll(int pageNum, int pageSize ,String code);


}
