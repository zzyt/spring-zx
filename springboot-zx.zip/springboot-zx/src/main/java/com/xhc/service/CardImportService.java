package com.xhc.service;

import com.xhc.model.ImportRecord;

import java.util.List;

public interface CardImportService {

    int addImportRecord(ImportRecord ImportRecord);

    List<ImportRecord> findAllPage(int pageNum, int pageSize, String startTime, String endTime);

    List<ImportRecord> findAll();
}
