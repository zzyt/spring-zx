package com.xhc.service.imp;

import com.github.pagehelper.PageHelper;
import com.xhc.mapper.ImportRecordMapper;
import com.xhc.model.ImportRecord;
import com.xhc.service.CardImportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class CardImportServiceImpl implements CardImportService {

    @Autowired
    private ImportRecordMapper importRecordMapper;

    @Transactional
    @Override
    public int addImportRecord(ImportRecord importRecord) {
        return importRecordMapper.insert(importRecord);
    }

    @Override
    public List<ImportRecord> findAllPage(int pageNum, int pageSize, String startTime, String endTime) {
        //将参数传给这个方法就可以实现物理分页了，非常简单。
        PageHelper.startPage(pageNum, pageSize);
        return importRecordMapper.findAll(startTime, endTime);
    }

    @Override
    public List<ImportRecord> findAll() {
        return importRecordMapper.findAll(null, null);
    }

    public Integer insertSelective(ImportRecord importRecord){
        return importRecordMapper.insertSelective(importRecord);
    }
}
