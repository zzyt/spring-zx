package com.xhc.service.imp;

import com.github.pagehelper.PageHelper;
import com.xhc.mapper.DeclareRecordMapper;
import com.xhc.model.DeclareRecord;
import com.xhc.service.DeclareRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class DeclareRecordServiceImpl implements DeclareRecordService{

    @Autowired
    private DeclareRecordMapper declareRecordMapper;

    @Override
    public List<DeclareRecord> findAllPage(int pageNum, int pageSize, String declareCardCode) {
        PageHelper.startPage(pageNum, pageSize);
        return declareRecordMapper.findAll(declareCardCode);
    }

    @Override
    public List<DeclareRecord> findAll(String declareCardCode) {
        return declareRecordMapper.findAll(declareCardCode);
    }

    @Override
    public List<Map<String,String>> findWeekInfo() {
        List<Map<String,String>> listMap = declareRecordMapper.findWeekInfo();
        return listMap;
    }
}
