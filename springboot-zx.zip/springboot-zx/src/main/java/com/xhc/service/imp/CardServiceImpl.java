package com.xhc.service.imp;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.xhc.mapper.CardMapper;
import com.xhc.mapper.ImportRecordMapper;
import com.xhc.model.Card;
import com.xhc.model.ImportRecord;
import com.xhc.service.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

@Service
public class CardServiceImpl implements CardService {
    @Autowired
    private CardImportServiceImpl cardImportServiceImpl;
    @Autowired
    private CardMapper cardMapper;

    @Override
    public int addCard(Card card) {
        return 0;
    }

    @Override
    public List<Card> findAll(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return cardMapper.findAll();
    }

    @Transactional
    @Override
    public void saveImportAndCard(List<Card> cardList) {
        ImportRecord cardImportRecord = new ImportRecord();
        cardImportRecord.setImportNum(cardList.size());
        cardImportRecord.setImportTime(new Date());
        cardImportRecord.setValidMouth(3);
        cardImportRecord.setEnable(0);
        Integer importRecordId = cardImportServiceImpl.insertSelective(cardImportRecord);
        for(Card card : cardList){
            card.setImportRecordId(cardImportRecord.getId());
        }
        insertBatch(cardList);
    }

    @Override
    public void insertBatch(List<Card> cardList) {
        cardMapper.insertBatch(cardList);
    }

    @Override
    public List<Card> findPageByImportId(Integer importId, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return cardMapper.findAllByImportId(importId);
    }

    @Override
    public List<Card> findAllByImportId(Integer importId) {
        return cardMapper.findAllByImportId(importId);
    }

    @Override
    public int findCount() {
        return cardMapper.findCount();
    }

    @Override
    public List<Card> findAll(String code) {
        return null;
    }

    @Override
    public List<Card> findAll(int pageNum, int pageSize, String code) {
        PageHelper.startPage(pageNum, pageSize);
        return cardMapper.findAllLikeCode(code);
    }

}
