package com.xhc.mapper;

import com.xhc.model.Card;

import java.util.List;

public interface CardMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Card record);

    int insertSelective(Card record);

    Card selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Card record);

    int updateByPrimaryKey(Card record);

    void insertBatch(List<Card> cardList);

    List<Card> findAllByImportId(Integer importId);

    int findCount();

    List<Card> findAllLikeCode(String code);

    List<Card> findAll();

}