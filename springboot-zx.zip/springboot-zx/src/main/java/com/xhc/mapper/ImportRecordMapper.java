package com.xhc.mapper;

import com.xhc.model.ImportRecord;

import java.util.List;

public interface ImportRecordMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ImportRecord record);

    int insertSelective(ImportRecord record);

    ImportRecord selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ImportRecord record);

    int updateByPrimaryKey(ImportRecord record);

    List<ImportRecord> findAll(String startTime, String endTime);

    List<ImportRecord> findAllPage();
}