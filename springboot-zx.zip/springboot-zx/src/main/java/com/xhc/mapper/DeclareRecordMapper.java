package com.xhc.mapper;

import com.xhc.model.DeclareRecord;

import java.util.List;
import java.util.Map;

public interface DeclareRecordMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(DeclareRecord record);

    int insertSelective(DeclareRecord record);

    DeclareRecord selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(DeclareRecord record);

    int updateByPrimaryKey(DeclareRecord record);

    List<DeclareRecord> findAllPage(int pageNum, int pageSize);

    List<DeclareRecord> findAll(String declareCardCode);

    List<Map<String,String>> findWeekInfo();

}